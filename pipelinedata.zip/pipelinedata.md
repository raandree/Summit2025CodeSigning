# App for pipeline use

Name | Value
--- | ---
TenantId | a1627b4f-281e-4f8b-bf13-bddc0eb6857e
KeyVaultName | Summit2025Test
AppId | 9a448c96-1905-49c6-b7bc-f922c34d98f4
Secret | Ca38Q~ritBvCXVuMyIhTHJYaN_lGR5xEJBRDBaem
